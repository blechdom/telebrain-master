# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - Extension Converter Package

    @copyright: 2006 MoinMoin:ThomasWaldmann
    @license: GNU GPL, see COPYING for details.
"""

# -*- coding: iso-8859-1 -*-

from MoinMoin.util import pysupport

modules = pysupport.getPackageModules(__file__)

